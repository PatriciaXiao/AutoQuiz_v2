<!-- https://github.com/wenzhixin/bootstrap-table/blob/develop/CONTRIBUTING.md#bug-reports -->


Please read: https://github.com/wenzhixin/bootstrap-table/blob/develop/CONTRIBUTING.md#bug-reports
and post issue to: https://github.com/wenzhixin/bootstrap-table/issues, thanks!
