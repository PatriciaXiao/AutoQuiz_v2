Highlight.js
============

Shim repository for [Highlight.js](http://highlightjs.org/).

Package Managers
----------------

* [Bower](http://bower.io): `highlightjs`
* [Composer](http://packagist.org/packages/components/highlightjs): `components/highlightjs`
* [Component](http://component.io): `components/highlightjs`
