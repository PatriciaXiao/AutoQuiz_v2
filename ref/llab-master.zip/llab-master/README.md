llab
====

Lightweight lab curriculum system

LLAB is a simple frame for building a course website for a sequence of activities. The goal of llab is to not be imposing, and use a simple directory structure (which you create!) to organize content. llab is mainly some Javascript wrappers and setup around basic HTML pages. It is designed to be easily deployed on any file server with no configuration.

We have an example repository in [bjc-r][bjcr]. For all comments or issues with the BJC curriculum, please see the BJC repo.

[bjcr]: https://github.com/beautyjoy/bjc-r/
