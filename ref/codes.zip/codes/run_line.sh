#!/bin/bash

netword_file="" # input file
vector_file="" # output file
binary="" # whether using binary format
size="" # embedding dimension
order="" # proximity (1 or 2)
negative="" #  number of samples in negative sampling
samples="" # number of edges for training
threads="" # number of threads for training
depth="" # depth of breadth first search

vocab_file="" # the vocabulary of nodes, which is used for evaluation.
label_file="" # the label of nodes, which is used for evaluation.

./line/line -train ${netword_file} -output ${vector_file} -debug 2 -binary ${binary} -size ${size} -order ${order} -negative ${negative} -samples ${samples} -depth ${depth} -threads ${threads}

cp ${vocab_file} evaluate/program
cp ${label_file} evaluate/program
cp ${vector_file} evaluate/vec.emb

cd evaluate
./run.sh vec.emb
python score.py result.txt
rm -rf vec.emb result.txt
cd ..