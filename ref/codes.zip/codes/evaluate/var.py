import sys
import os

vec = []

input_file = sys.argv[1]
fi = open(input_file, 'r')
for line in fi:
    curvec = []
    lst = line.split(' ')
    for en in lst:
        try:
            f = float(en)
        except ValueError:
            continue
        curvec.append(f)
    vec.append(curvec)
fi.close()

size = len(vec[0])
avr = [0 for i in range(size)]
n = 0

for v in vec:
    for i in range(size):
        avr[i] = avr[i] + v[i]
    n = n + 1

for i in range(size):
    avr[i] = avr[i] / n

print size
print n

var = 0

for v in vec:
    for i in range(size):
        var = var + (v[i] - avr[i]) * (v[i] - avr[i])

print var
    
