import sys
import os

fi = open('label.txt')
fo = open('tmp.txt', 'w')

cnt = [0 for i in range(100)]

for line in fi:
    lb = int(line.split('\t')[1])
    cnt[lb] = cnt[lb] + 1

for i in range(1,48):
    fo.write(str(cnt[i])+'\n')

fi.close()
fo.close()
