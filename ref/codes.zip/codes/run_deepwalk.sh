#!/bin/bash

netword_file=""
vector_file=""
binary=""
size=""
iterations="" # number of iterations
length="" # the length of each random walk
window="" # the window size
threads=""

vocab_file=""
label_file=""

./deepwalk/deepwalk -train ${netword_file} -output ${vector_file} -debug 2 -binary ${binary} -size ${size} -iterations ${iterations} -length ${length} -window ${window} -threads ${threads}

cp ${vocab_file} evaluate/program
cp ${label_file} evaluate/program
cp ${vector_file} evaluate/vec.emb

cd evaluate
./run.sh vec.emb
python score.py result.txt
rm -rf vec.emb result.txt
cd ..