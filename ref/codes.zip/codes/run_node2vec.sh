#!/bin/bash

netword_file=""
vector_file=""
binary=""
size=""
iterations=""
length=""
window=""
threads=""
p=""
q=""

vocab_file=""
label_file=""

./node2vec/node2vec -train ${netword_file} -output ${vector_file} -debug 2 -binary ${binary} -size ${size} -iterations ${iterations} -length ${length} -window ${window} -p ${p} -q {q} -threads ${threads}

cp ${vocab_file} evaluate/program
cp ${label_file} evaluate/program
cp ${vector_file} evaluate/vec.emb

cd evaluate
./run.sh vec.emb
python score.py result.txt
rm -rf vec.emb result.txt
cd ..